export default function Home() {
  return (
    <div style={{ padding: '40px', fontFamily: 'Arial' }}>
      <h1>✅ Douane.IA Phase 0</h1>
      <p>Bienvenue! Le serveur fonctionne.</p>
      <a href="/auth/login" style={{ color: 'blue' }}>
        Aller à Login →
      </a>
    </div>
  )
}
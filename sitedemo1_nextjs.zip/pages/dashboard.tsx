import { useRouter } from 'next/router'

export default function Dashboard() {
  const router = useRouter()
  const stats = [
    { label: 'Dossiers actifs', value: '3', color: '#ff9800' },
    { label: 'En attente', value: '5', color: '#dc3545' },
    { label: 'Approuvés', value: '12', color: '#28a745' },
    { label: 'Économies', value: '€8,450', color: '#007bff' },
  ]

  return (
    <div style={{ minHeight: '100vh', background: '#f5f5f5', fontFamily: 'Arial' }}>
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg, #007bff 0%, #0056b3 100%)', color: 'white', padding: '30px 20px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 style={{ margin: 0, fontSize: '32px' }}>📊 Dashboard Douane.IA</h1>
            <p style={{ margin: '5px 0 0 0', opacity: 0.9 }}>Bienvenue! Gérez vos dossiers douaniers facilement.</p>
          </div>
          <button 
            onClick={() => router.push('/auth/login')} 
            style={{ 
              padding: '10px 20px', 
              background: 'rgba(255,255,255,0.2)', 
              color: 'white', 
              border: '2px solid white',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            Déconnexion
          </button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '30px 20px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginBottom: '40px' }}>
          {stats.map((stat, idx) => (
            <div key={idx} style={{
              background: 'white',
              padding: '20px',
              borderRadius: '8px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              borderTop: `4px solid ${stat.color}`
            }}>
              <p style={{ margin: '0 0 10px 0', color: '#666', fontSize: '14px' }}>{stat.label}</p>
              <h2 style={{ margin: 0, fontSize: '28px', color: stat.color }}>{stat.value}</h2>
            </div>
          ))}
        </div>

        {/* Modules */}
        <h2 style={{ marginTop: 0 }}>Services Disponibles</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '8px', 
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.3s',
          }}
          onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          onClick={() => router.push('/chat')}
          >
            <div style={{ fontSize: '48px', marginBottom: '15px' }}>💬</div>
            <h3 style={{ margin: '0 0 10px 0' }}>Chat IA</h3>
            <p style={{ margin: '0 0 15px 0', color: '#666', fontSize: '14px' }}>
              Posez vos questions sur les régulations douanières
            </p>
            <button style={{ 
              padding: '10px 20px', 
              background: '#007bff', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}>
              Ouvrir
            </button>
          </div>

          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '8px', 
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.3s'
          }}
          onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          onClick={() => router.push('/search')}
          >
            <div style={{ fontSize: '48px', marginBottom: '15px' }}>🔍</div>
            <h3 style={{ margin: '0 0 10px 0' }}>Recherche ADII</h3>
            <p style={{ margin: '0 0 15px 0', color: '#666', fontSize: '14px' }}>
              Cherchez dans 10,000+ circulaires ADII
            </p>
            <button style={{ 
              padding: '10px 20px', 
              background: '#28a745', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}>
              Ouvrir
            </button>
          </div>

          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '8px', 
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.3s'
          }}
          onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          onClick={() => router.push('/dossiers')}
          >
            <div style={{ fontSize: '48px', marginBottom: '15px' }}>📁</div>
            <h3 style={{ margin: '0 0 10px 0' }}>Dossiers</h3>
            <p style={{ margin: '0 0 15px 0', color: '#666', fontSize: '14px' }}>
              Gérez et suivez vos dossiers douaniers
            </p>
            <button style={{ 
              padding: '10px 20px', 
              background: '#ff9800', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}>
              Ouvrir
            </button>
          </div>

          <div style={{ 
            background: 'white', 
            padding: '30px', 
            borderRadius: '8px', 
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            textAlign: 'center',
            cursor: 'pointer',
            transition: 'transform 0.3s'
          }}
          onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
          onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
          onClick={() => router.push('/settings')}
          >
            <div style={{ fontSize: '48px', marginBottom: '15px' }}>⚙️</div>
            <h3 style={{ margin: '0 0 10px 0' }}>Paramètres</h3>
            <p style={{ margin: '0 0 15px 0', color: '#666', fontSize: '14px' }}>
              Gérez votre compte et préférences
            </p>
            <button style={{ 
              padding: '10px 20px', 
              background: '#6c757d', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}>
              Ouvrir
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}